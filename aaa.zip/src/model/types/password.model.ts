
export interface Password {
    PasswordList: { [key: string]: string }
    Date: string
    IP: string
}