import { BaseResponse } from "./baseResponse"
export interface InspectResponse extends BaseResponse {
    Inspect: any
}