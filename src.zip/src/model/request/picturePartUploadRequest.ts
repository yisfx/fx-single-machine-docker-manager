interface PicturePartUploadRequest {
    PartIndex: number
    Value: string
    PictureName: string
    AlbumName: string
    IsLastPart: boolean
}