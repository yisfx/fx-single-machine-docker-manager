import { BaseResponse } from "./baseResponse";


interface Loginresponse extends BaseResponse{
    LoginToken:string
}