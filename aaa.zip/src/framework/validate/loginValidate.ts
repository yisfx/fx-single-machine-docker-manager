import { FastifyRequestWithCookie } from "../../model/types/FastifyReqWithCookie";



export const ValidateLogin = (token: string, request: FastifyRequestWithCookie) => {

    /// send request
    return true;

}