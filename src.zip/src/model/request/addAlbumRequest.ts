import { Album } from "../album";

export interface AddAlbumRequest {
    Album: Album
}