import { Container } from "../../../model/container";

export interface ManageStore {
    container: Container[]
}