import { exec } from "child_process";

exec("docker build -t wangsaihaizai/fxsmdm:v1 .")