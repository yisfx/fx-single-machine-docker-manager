
## Installation

```bash
$ npm install
```

## Running the app

```bash
# development
$ yarn start
```

## Stay in touch
- Website - [www.fxfxfxfx.cn](www.fxfxfxfx.cn)
