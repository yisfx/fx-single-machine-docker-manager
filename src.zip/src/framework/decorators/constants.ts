const Route_Name_Metadata = "__routename__"
const Layout_Name_Metadata = "__layoutname__"

export default { Route_Name_Metadata, Layout_Name_Metadata }