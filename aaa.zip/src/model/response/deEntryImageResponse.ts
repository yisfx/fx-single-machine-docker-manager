import { BaseResponse } from "./baseResponse";



export interface DeEntryImageLinkResponse extends BaseResponse {
    ImagePath: string
}