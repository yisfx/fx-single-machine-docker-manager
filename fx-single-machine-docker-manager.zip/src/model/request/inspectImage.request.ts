
export interface InspectImageRequest {
    ImageID: string
}