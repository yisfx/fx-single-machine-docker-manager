import React from "react";

export default class RenderMateData extends React.Component<any>{
    constructor(props) {
        super(props)
    }


    render() {
        return (
            <div></div>
        )
    }
}