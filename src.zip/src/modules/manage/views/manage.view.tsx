import React from "react"
import { Ajax } from "src/framework/httpclient/ajax"
import MasterPage from "../../../framework/master/@masterPage"
import Master from "../../../framework/master/master"
import { ManageStore } from "../store/manage.store"



function Container(props: ManageStore) {
    return <div className="container">
        <div className="row">
            <button>Image</button>
            <div className="table-responsive">
                <table className="table ">
                    <thead>
                        <tr>
                            <td>Container ID</td>
                            <td>Image</td>
                            <td>Command</td>
                            <td>Created</td>
                            <td>Status</td>
                            <td>Port</td>
                            <td>Name</td>
                            <td>Action</td>
                        </tr>
                    </thead>
                    <tbody>
                        {props.container.map(c =>
                            <tr>
                                <td>{c.ContainerID}</td>
                                <td>{c.Image}</td>
                                <td>{c.Command}</td>
                                <td>{c.Created}</td>
                                <td>{c.Status}</td>
                                <td>{c.Port}</td>
                                <td>{c.Name}</td>
                                <td>
                                    {c.Status.startsWith("Up") ?
                                        <button onClick={() => {
                                            Ajax("StartContainer", {})
                                        }}>stop</button>
                                        :
                                        <button>Start</button>
                                    }
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    </div>
}



require("../../../../static/css/manage.css")

@MasterPage(Master)
export default class Manage extends React.Component<ManageStore, any>{
    constructor(props) {
        super(props)
    }

    render() {
        return <div>
            <Container {...this.props} />

        </div>
    }
}